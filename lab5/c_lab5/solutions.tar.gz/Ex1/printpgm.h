//
// Created by mario on 27/02/19.
//

// size of image
#define ROWS 5
#define COLS 5

#define COLOURDEPTH 255

void printImage(int map[ROWS][COLS]);