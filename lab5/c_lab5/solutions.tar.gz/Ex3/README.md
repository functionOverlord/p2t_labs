to run, cd into this directory and type make.
after that simply execute mycode