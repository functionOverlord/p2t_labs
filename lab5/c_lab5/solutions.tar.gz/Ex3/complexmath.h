//
// Created by mario on 03/03/19.
//


// Calculate the real offset of the complex cube roots of areal , given the real root
double re_complexroots(double);

// Calculate the imaginary parts of the complex cube rootsof a real , given the real root
double im_complexroots(double);