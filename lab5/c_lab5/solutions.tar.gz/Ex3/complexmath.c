//
// Created by mario on 03/03/19.
//

#include <math.h>

double re_complexroots(double z) {
    return -1.0 * z / 2.0 ;
}

double im_complexroots(double z) {
    return sqrt(3.0)*(z/2.0);
}