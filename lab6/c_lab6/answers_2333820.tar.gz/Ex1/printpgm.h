// size of image
#define ROWS 5
#define COLS 5

#define COLOURDEPTH 255

void writeTextImage(char map[ROWS][COLS]);
void writeBinaryImage(char map[ROWS][COLS]);